
<main>
<div>
<h3>Formula One (also known as Formula 1 or F1) is the highest class of international racing for open-wheel single-seater formula racing cars sanctioned by the 
    Fédération Internationale de l'Automobile (FIA). The World Drivers' Championship, which became the FIA Formula One World Championship in 1981, has been one of the premier forms 
    of racing around the world since its inaugural season in 1950. The word formula in the name refers to the set of rules to which all participants' cars must conform. 
    A Formula One season consists of a series of races, known as Grands Prix, which take place worldwide on both purpose-built circuits and closed public roads.</h3>
</div>
<div>
    <h2>Current Champion:Max Verstapen</h2><img src="img/verstappen.png">
    <h2>Current Constructor Champion:Mercedes</h2><img src="img/mercedes W12.jpg">
    <h2>Next GP:Singapore</h2><img src="img/singapore.png">
    <h2>Last GP(Italy) Winner:Max Verstapen</h2><img src="img/verstappen.png">
    <h2>Last GP(Italy) Pole Sitter:Charles Leclerc</h2><img src="img/leclerc.png">
</div>
</main>
