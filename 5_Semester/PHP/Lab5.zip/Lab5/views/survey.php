﻿

    <div>
        <form>
            <label>Input your age.</label><br>
            <input type="number" id="age" name="age"><br>
            <label>Which transport you own?</label><br>            
            <label for="vehicle1"><input type="radio" id="vehicle1" name="transport" value="Bike">Bike</label><br>            
            <label for="vehicle2"><input type="radio" id="vehicle2" name="transport" value="Car">Car</label><br>            
            <label for="vehicle3"><input type="radio" id="vehicle3" name="transport" value="Racing car">Racing car</label><br>            
            <label for="vehicle4"><input type="radio" id="vehicle4" name="transport" value="Motorcycle">Motorcycle</label><br>            
            <label for="vehicle5"><input type="radio" id="vehicle5" name="transport" value="Other">Other</label><br><br>
            <label>Which team do you support?</label><br>   
            <select name="teams" id="teams">
                <option value="Mercedes">Mercedes</option>
                <option value="Ferrari">Ferrari</option>
                <option value="Alpine">Alpine</option>
                <option value="RedBull">RedBull</option>
                <option value="Haas">Haas</option>
                <option value="AstonMartin">Aston Martin</option>
                <option value="McLaren">McLaren</option>
                <option value="Alfa Romeo">Alfa Romeo</option>
                <option value="Williams">Williams</option>
                <option value="AlphaTauri">AlphaTauri</option>
            </select><br><br>
            <label>Which Grand Prix you want to visit in 2023?</label><br>
            <label for="GP1"><input type="checkbox" name="GP1">Bahrain</input></label><br>
            <label for="GP2"><input type="checkbox" name="GP2">Saudi Arabia</input></label><br>
            <label for="GP3"><input type="checkbox" name="GP3">Australia</input></label><br>
            <label for="GP4"><input type="checkbox" name="GP4">China</input></label><br>
            <label for="GP5"><input type="checkbox" name="GP5">Azerbaijan</input></label><br>
            <label for="GP6"><input type="checkbox" name="GP6">Miami</input></label><br>
            <label for="GP7"><input type="checkbox" name="GP7">Emilia Romagna</input></label><br>
            <label for="GP8"><input type="checkbox" name="GP8">Monaco</input></label><br>
            <label for="GP9"><input type="checkbox" name="GP9">Spain</input></label><br>
            <label for="GP10"><input type="checkbox" name="GP10">canada</input></label><br>
            <label for="GP11"><input type="checkbox" name="GP11">Austria</input></label><br>
            <label for="GP12"><input type="checkbox" name="GP12">United Kingdom</input></label><br>
            <label for="GP13"><input type="checkbox" name="GP13">Hungary</input></label><br>
            <label for="GP14"><input type="checkbox" name="GP14">Belgium</input></label><br>
            <label for="GP15"><input type="checkbox" name="GP15">Netherlands</input></label><br>
            <label for="GP16"><input type="checkbox" name="GP16">Italy</input></label><br>
            <label for="GP17"><input type="checkbox" name="GP17">Singapore</input></label><br>
            <label for="GP18"><input type="checkbox" name="GP18">Japan</input></label><br>
            <label for="GP19"><input type="checkbox" name="GP19">Qatar</input></label><br>
            <label for="GP20"><input type="checkbox" name="GP20">USA</input></label><br>
            <label for="GP21"><input type="checkbox" name="GP21">Mexico</input></label><br>
            <label for="GP22"><input type="checkbox" name="GP22">Brazil</input></label><br>
            <label for="GP23"><input type="checkbox" name="GP23">Las Vegas</input></label><br>
            <label for="GP24"><input type="checkbox" name="GP24">Abu Dhabi</input></label><br>

            <input type="submit">
        </form>

    </div>
