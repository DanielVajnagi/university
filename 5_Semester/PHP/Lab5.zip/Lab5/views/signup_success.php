<h2>Signup successfull!!!</h2>
<a href="?action=main"><button>Main Page</button></a>