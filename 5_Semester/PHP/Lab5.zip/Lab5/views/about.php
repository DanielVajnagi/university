<?php   include("header.php");
        include("main.php");
        include("footer.php");?>
<p>This site is created by CS student @daniel_vajnagi</p>