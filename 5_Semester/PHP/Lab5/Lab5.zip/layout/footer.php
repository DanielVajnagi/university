<footer>
        This site was made by @daniel_vajnagi
</footer>
</body>
</html>